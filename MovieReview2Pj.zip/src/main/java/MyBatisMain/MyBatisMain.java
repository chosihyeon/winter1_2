package MyBatisMain;

import kr.ac.kopo.dao.CommentDAO;

public class MyBatisMain {

	public static void main(String[] args) throws Exception {
		CommentDAO dao = new CommentDAO();
		dao.work();
		
		
		
		

	}

}
