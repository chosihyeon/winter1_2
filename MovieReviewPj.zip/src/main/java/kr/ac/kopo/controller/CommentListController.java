package kr.ac.kopo.controller;

import java.util.ArrayList;
import java.util.List;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import kr.ac.kopo.vo.CommentVO;

public class CommentListController implements Controller {

	@Override
	public String handleRequest(HttpServletRequest request, HttpServletResponse response)
		throws Exception {
		
		List<CommentVO> commentList = new ArrayList<>();
		
		request.setAttribute("commentList", commentList);
		return "/jsp/comment/list.jsp";
	}

}
